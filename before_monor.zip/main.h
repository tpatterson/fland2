#ifndef MAIN_H
#define MAIN_H

using namespace std;

#include <fstream>
#include "defines.h"
#include "fland.h"

// some function prototypes
int initProgram();
int mainLoop();
int closeProgram();
int mainLoop();
int closeProgram();
void resetFland( int seed );



class Globals
{
	public:
	// Create an output file stream for logging
};
#endif

