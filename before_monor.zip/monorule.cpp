
#ifndef MonoRule_CPP // TODO: insert class name before _CPP
#define MonoRule_CPP
/*
	MonoRule
	- Applies to:
		eg. Verticies

	- Description:

	- Values it can recieve

	- How it works

*/

#include <iostream>
#include <sstream>
#include "tyler.h"
#include "templates.h"
#include "baserule.h"

class MonoRule : public BaseRule
{
	public:
	MonoRule();
	virtual MonoRule();

	virtual void destructor( bool willDelete = false );

	// This makes the rule do it's thing. Call it and pass the entity that
	// is using the rule (client), and the rule will alter the appropriate attributes
	// of the client.
	virtual void goCalcMe( BaseEnt *inClient, intensityType runIntensity );

	// used in the parse functions. assigns value to valuetype.
	// returns an error, if there was one. Otherwise, returns blank ( "" )
	virtual string assignValue( string valueType, istringstream *value, FmlParser* fPtr );

	#if( DEBUG )
	virtual string toString( int );
	virtual string getType(){ return "MonoRule"; }
	#endif
	static Reuse< BaseRule, MonoRule > reuse;

};

// EVERYTHING AFTER THIS GOES IN THE .CPP
#if( DEBUG )
string MonoRule::toString( int i )
{
	ostringstream out;
	ind = indent( i );
	out << ind << " MonoRule::\n";
	out << BaseRule::toString( i );
	return out.str();
}
#endif

// mention the reuse rule class
Reuse< BaseRule, MonoRule > MonoRule::reuse;


string MonoRule::assignValue( string valueType, istringstream *value, FmlParser* fPtr )
{
	if( valueType == "test1" )
	{
		// *value >> test1;
	}
	else
	{
		return BaseRule::assignValue( valueType, value, fPtr );
	}
	return "";
}

MonoRule::MonoRule()
	:BaseRule();
{

}

void MonoRule::destructor( bool willDelete )
{

	BaseRule::destructor( willDelete );
}

void MonoRule::goCalcMe( BaseEnt *inClient, intensityType runIntensity )
{
	cout << "need to overload goCalcMe still! "; LN
}

#endif
